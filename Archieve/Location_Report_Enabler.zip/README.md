# **Location Report Enabler**

## Description

Enable Google Location Report and Google Map Timeline in China(RPC).

Just set property value below after registered celler network.

```bash
setprop gsm.sim.operator.numeric 310030
setprop gsm.sim.operator.iso-country us
```

## Changelog

- v20180830

first release

## Requirements

No Requirements.

**But if you use some [sponsored data service](https://developer.att.com/sponsored-data/support/sponsored-data-api-faqs#whats-sponsored-data), you would better check if it works normally.**

*I tested it for China Uniform, and it seems work well.*

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
