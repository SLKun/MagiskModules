# **ICU Data Library Replacer**

## Description

This module replaces the default icudt58l.dat file with a new one correctly edited for replacing Chinese to English.

Fix for Chinsese Localization for data size unit.
```
Example:
    '吉比特' -> GB
```

## Changelog

- v20180830

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
