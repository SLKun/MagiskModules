# **Gallery Replacer**

## Description

Replace Android Gallery with SnapGallery

## Changelog

- v20181125

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
