# **Google Camera for MIUI on XiaoMi 5**

## Description

This module enables HAL3 and fix front camera on Mi5, plus Gcam for MIUI.

## Changelog

- v20180830

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
