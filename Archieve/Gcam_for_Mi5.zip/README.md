# Google Camera for MIUI on XiaoMi 5
This module enables HAL3 and fix front camera on Mi5, plus Gcam for MIUI.

## Instructions ##

* __Install Module__ via Magisk Manager/TWRP
* __Reboot__ Device
* __Use__ builtin Google Camera for MIUI.

## Changelog ##

##### V1.0.0 #####
* __Initial Release__
