# **Location Report Enabler**

## Description

Disable System Mipush for unofficial MIUI, for using [MiPushFramework](https://github.com/Trumeet/MiPushFramework).

## Changelog

- v20180

first release

## Requirements

No Requirements.

**But if you use some [sponsored data service](https://developer.att.com/sponsored-data/support/sponsored-data-api-faqs#whats-sponsored-data), you would better check if it works normally.**

*I tested it for China Uniform, and it seems work well.*

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
