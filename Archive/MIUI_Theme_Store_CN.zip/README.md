# **MIUI Theme Store CN**

## Description

Enable CN MIUI Theme Store for miui.eu.

## Changelog

- v20180911

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
