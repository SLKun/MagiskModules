# **Tweaks on Mi5**

## Description

- fingerprint wakeup

Very excellent feature for Mi5, you will forget the home button can be pressed.

- disbale ramdump

Seems useless for end users, and it will generat a folder at /sdcard. It really bother me.

- disbale LMK log

Maybe useless log, anyway I don't need it.

- enable wcd9330 features

Some features that maybe optimize music quality, only for wcd9330(SD820).

## Changelog

- v20180830

first release

## Requirements

No Requirements except you use XiaoMi 5 or at least SD820.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
