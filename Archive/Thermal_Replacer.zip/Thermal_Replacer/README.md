# **Custom Thermal File**

## Description

This module replaces the default thermal-engine-8996.conf file with a custom file.

## Changelog

- v20190614

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
