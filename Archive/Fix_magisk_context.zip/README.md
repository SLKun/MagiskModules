# **Fix Magisk Context**

## Description

Fix selinux context for magisk modules on v19.1 (maybe later)
Use post-fs-data.sh to set_perm_recursive on /data/adb/modules

## Changelog

- v20190513

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
