# **CN Optimized GPS File Replacer**

## Description

This module replaces the default gps.conf file with a new one correctly edited for a better improvement and faster locking.

## Changelog

- v20180830

first release

## Requirements

No Requirements.

## Instructions

Just download and install it.

## Links

[Latest stable Magisk](http://www.tiny.cc/latestmagisk)
